package com.hile;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.hile.module.Module;
import com.hile.module.ModuleManager;
import com.hile.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private Config() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("hile.json");
    }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : ModuleManager.getModules()) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.isEnabled());
                o.addProperty("key", m.getKey());
                JsonObject s = new JsonObject();
                for (Setting st : m.getSettings()) s.add(st.getName(), st.toJson());
                o.add("settings", s);
                root.add(m.getName(), o);
            }
            Files.writeString(file(), GSON.toJson(root));
        } catch (Exception ignored) {
        }
    }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            JsonObject root = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            for (Module m : ModuleManager.getModules()) {
                if (!root.has(m.getName())) continue;
                JsonObject o = root.getAsJsonObject(m.getName());
                if (o.has("key")) m.setKey(o.get("key").getAsInt());
                if (o.has("settings")) {
                    JsonObject s = o.getAsJsonObject("settings");
                    for (Setting st : m.getSettings()) {
                        if (s.has(st.getName())) st.fromJson(s.get(st.getName()));
                    }
                }
                if (o.has("enabled")) m.setEnabled(o.get("enabled").getAsBoolean(), false);
            }
        } catch (Exception ignored) {
        }
    }
}
