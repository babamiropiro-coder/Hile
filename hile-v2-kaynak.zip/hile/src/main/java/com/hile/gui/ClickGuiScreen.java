package com.hile.gui;

import com.hile.Config;
import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.module.ModuleManager;
import com.hile.module.impl.Interface;
import com.hile.setting.BoolSetting;
import com.hile.setting.ModeSetting;
import com.hile.setting.NumberSetting;
import com.hile.setting.Setting;
import com.hile.util.Render2D;
import com.hile.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ClickGuiScreen extends Screen {
    private static final int PW = 112;
    private static final int HEADER = 18;
    private static final int ROW = 16;

    private static final List<Panel> PANELS = new ArrayList<>();
    private static final Map<Module, Float> HOVER = new HashMap<>();
    private static final Map<Module, Float> EXPAND = new HashMap<>();
    private static final Set<Module> OPEN = new HashSet<>();

    private interface Click { void run(int button, double mx, double my); }

    private record Zone(int x1, int y1, int x2, int y2, Click click) {}

    private static final class Panel {
        final Category category;
        int x, y;
        Panel(Category category, int x, int y) { this.category = category; this.x = x; this.y = y; }
    }

    private final List<Zone> zones = new ArrayList<>();
    private final long openTime = System.nanoTime();
    private long lastFrame = System.nanoTime();
    private float alpha;
    private boolean opened;

    private Panel dragging;
    private int dragDX, dragDY;
    private NumberSetting slider;
    private int sliderX, sliderW;
    private Module binding;
    private String tooltip;

    public ClickGuiScreen() {
        super(Text.literal("Hile"));
        if (PANELS.isEmpty()) {
            int i = 0;
            for (Category c : Category.values()) {
                PANELS.add(new Panel(c, 10 + i * (PW + 8), 12));
                i++;
            }
        }
    }

    @Override
    protected void init() {
        if (!opened) {
            opened = true;
            Interface.playOpen();
        }
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void removed() {
        Config.save();
        Interface.playClose();
    }

    // ---------------------------------------------------------------- helpers

    private int c(int argb) {
        int a = (int) (((argb >>> 24) & 0xFF) * alpha);
        return (a << 24) | (argb & 0xFFFFFF);
    }

    private void text(DrawContext ctx, String s, int x, int y, int color) {
        int col = c(color);
        if (((col >>> 24) & 0xFF) < 8) return;
        ctx.drawText(textRenderer, s, x, y, col, true);
    }

    private static float approach(Map<Module, Float> map, Module m, float target, float step) {
        float v = map.getOrDefault(m, 0f);
        v += (target - v) * Math.min(1f, step);
        if (Math.abs(target - v) < 0.002f) v = target;
        map.put(m, v);
        return v;
    }

    private static int settingH(Setting s) { return s instanceof NumberSetting ? 20 : 14; }

    private static int settingsHeight(Module m) {
        int h = 14 + 4;
        for (Setting s : m.getSettings()) h += settingH(s);
        return h;
    }

    private static String keyName(int key) {
        try {
            return InputUtil.fromKeyCode(key, 0).getLocalizedText().getString();
        } catch (Throwable t) {
            return String.valueOf(key);
        }
    }

    private static void toggleOpen(Module m) {
        if (!OPEN.remove(m)) OPEN.add(m);
        Interface.playTick();
    }

    private void applySlider(double mouseX) {
        if (slider == null || sliderW <= 0) return;
        double pct = MathHelper.clamp((mouseX - sliderX) / sliderW, 0.0, 1.0);
        slider.set(slider.getMin() + pct * (slider.getMax() - slider.getMin()));
    }

    // ---------------------------------------------------------------- render

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastFrame) / 1_000_000_000f);
        lastFrame = now;
        float t = Math.min(1f, (now - openTime) / 220_000_000f);
        alpha = 1f - (1f - t) * (1f - t);
        float step = dt * 14f;

        zones.clear();
        tooltip = null;

        ctx.fillGradient(0, 0, width, height, c(0xC0050510), c(0xC0160A28));

        for (Panel p : PANELS) drawPanel(ctx, p, mx, my, step);

        if (tooltip != null) {
            int tw = textRenderer.getWidth(tooltip) + 8;
            int tx = MathHelper.clamp(mx + 10, 2, Math.max(2, width - tw - 2));
            int ty = MathHelper.clamp(my + 12, 2, Math.max(2, height - 16));
            Render2D.rect(ctx, tx, ty, tw, 13, 3, c(0xF0101018));
            text(ctx, tooltip, tx + 4, ty + 3, 0xFFE8E8F0);
        }
    }

    private void drawPanel(DrawContext ctx, Panel p, int mx, int my, float step) {
        int x = p.x, y = p.y;
        List<Module> mods = ModuleManager.byCategory(p.category);

        // measure
        int content = 2;
        for (Module m : mods) {
            float ea = EXPAND.getOrDefault(m, 0f);
            content += ROW + Math.round(settingsHeight(m) * ea);
        }
        int total = HEADER + content + 2;

        Render2D.rect(ctx, x, y, PW, total, 5, c(0xE0101018));
        Render2D.rect(ctx, x, y, PW, HEADER, 5, c(0xF01A1A2A));
        ctx.fill(x, y + HEADER - 5, x + PW, y + HEADER, c(0xF01A1A2A));
        for (int i = 0; i < PW; i += 4) {
            ctx.fill(x + i, y + HEADER - 1, x + Math.min(i + 4, PW), y + HEADER, c(Theme.accent(i * 3f)));
        }

        String title = p.category.label();
        text(ctx, title, x + (PW - textRenderer.getWidth(title)) / 2, y + 5, 0xFFFFFFFF);

        zones.add(new Zone(x, y, x + PW, y + HEADER, (btn, qx, qy) -> {
            if (btn == 0) {
                dragging = p;
                dragDX = (int) qx - p.x;
                dragDY = (int) qy - p.y;
            }
        }));

        int cy = y + HEADER + 2;
        for (Module m : mods) {
            int rx = x + 3, rw = PW - 6;
            boolean hovered = mx >= rx && mx < rx + rw && my >= cy && my < cy + ROW;
            float hv = approach(HOVER, m, hovered ? 1f : 0f, step);
            int accent = Theme.accent(cy * 0.8f);

            if (m.isEnabled()) Render2D.rect(ctx, rx, cy, rw, ROW - 1, 3, c(Theme.alpha(accent, 60)));
            if (hv > 0.02f) Render2D.rect(ctx, rx, cy, rw, ROW - 1, 3, c(((int) (36 * hv) << 24) | 0xFFFFFF));
            if (m.isEnabled()) ctx.fill(rx, cy + 3, rx + 2, cy + ROW - 4, c(accent));

            text(ctx, m.getName(), rx + 7, cy + 4, m.isEnabled() ? accent : 0xFFD6D6E2);
            text(ctx, OPEN.contains(m) ? "-" : "+", rx + rw - 9, cy + 4, 0xFF9A9AB0);
            if (hovered) tooltip = m.getDescription();

            zones.add(new Zone(rx, cy, rx + rw - 16, cy + ROW, (btn, qx, qy) -> {
                if (btn == 0) m.toggle();
                else if (btn == 1) toggleOpen(m);
            }));
            zones.add(new Zone(rx + rw - 16, cy, rx + rw, cy + ROW, (btn, qx, qy) -> toggleOpen(m)));

            float ea = approach(EXPAND, m, OPEN.contains(m) ? 1f : 0f, step);
            int sh = Math.round(settingsHeight(m) * ea);
            if (sh > 1) {
                ctx.enableScissor(x + 3, cy + ROW, x + PW - 3, cy + ROW + sh);
                int yy = cy + ROW;
                boolean live = ea > 0.97f;
                for (Setting s : m.getSettings()) yy = drawSetting(ctx, s, x, yy, accent, live);
                drawBind(ctx, m, x, yy, accent, live);
                ctx.disableScissor();
            }
            cy += ROW + sh;
        }
    }

    private int drawSetting(DrawContext ctx, Setting s, int px, int yy, int accent, boolean live) {
        int sx = px + 6, sw = PW - 12;
        int h = settingH(s);

        if (s instanceof BoolSetting b) {
            text(ctx, b.getName(), sx + 2, yy + 3, 0xFFB4B4C4);
            int bx = sx + sw - 18;
            boolean on = b.get();
            Render2D.rect(ctx, bx, yy + 3, 16, 8, 4, c(on ? accent : 0xFF3A3A4A));
            Render2D.rect(ctx, on ? bx + 9 : bx + 1, yy + 4, 6, 6, 3, c(0xFFFFFFFF));
            if (live) zones.add(new Zone(sx, yy, sx + sw, yy + h, (btn, qx, qy) -> {
                b.toggle();
                Interface.playTick();
            }));
        } else if (s instanceof NumberSetting n) {
            text(ctx, n.getName(), sx + 2, yy + 2, 0xFFB4B4C4);
            String v = n.display();
            text(ctx, v, sx + sw - textRenderer.getWidth(v) - 2, yy + 2, 0xFFFFFFFF);
            int tx = sx + 2, tw = sw - 4, ty = yy + 13;
            Render2D.rect(ctx, tx, ty, tw, 3, 1, c(0xFF2C2C3A));
            float pct = (float) ((n.get() - n.getMin()) / (n.getMax() - n.getMin()));
            int fw = Math.max(2, Math.round(tw * pct));
            Render2D.rect(ctx, tx, ty, fw, 3, 1, c(accent));
            Render2D.rect(ctx, tx + fw - 2, ty - 1, 5, 5, 2, c(0xFFFFFFFF));
            if (live) zones.add(new Zone(tx - 2, yy, tx + tw + 2, yy + h, (btn, qx, qy) -> {
                slider = n;
                sliderX = tx;
                sliderW = tw;
                applySlider(qx);
            }));
        } else if (s instanceof ModeSetting md) {
            text(ctx, md.getName(), sx + 2, yy + 3, 0xFFB4B4C4);
            String v = md.get();
            text(ctx, v, sx + sw - textRenderer.getWidth(v) - 2, yy + 3, accent);
            if (live) zones.add(new Zone(sx, yy, sx + sw, yy + h, (btn, qx, qy) -> {
                md.cycle(btn == 1 ? -1 : 1);
                Interface.playTick();
            }));
        }
        return yy + h;
    }

    private void drawBind(DrawContext ctx, Module m, int px, int yy, int accent, boolean live) {
        int sx = px + 6, sw = PW - 12;
        String label = binding == m ? "..." : (m.getKey() == -1 ? "None" : keyName(m.getKey()));
        String shown = "[" + label + "]";
        text(ctx, "Bind", sx + 2, yy + 3, 0xFFB4B4C4);
        text(ctx, shown, sx + sw - textRenderer.getWidth(shown) - 2, yy + 3, binding == m ? 0xFFFFFFFF : accent);
        if (live) zones.add(new Zone(sx, yy, sx + sw, yy + 14, (btn, qx, qy) -> {
            if (btn == 1) m.setKey(-1);
            else binding = m;
        }));
    }

    // ---------------------------------------------------------------- input

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (int i = zones.size() - 1; i >= 0; i--) {
            Zone z = zones.get(i);
            if (mx >= z.x1() && mx < z.x2() && my >= z.y1() && my < z.y2()) {
                z.click().run(button, mx, my);
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) {
            dragging.x = MathHelper.clamp((int) mx - dragDX, 0, Math.max(0, width - PW));
            dragging.y = MathHelper.clamp((int) my - dragDY, 0, Math.max(0, height - HEADER));
            return true;
        }
        if (slider != null) {
            applySlider(mx);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = null;
        slider = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (binding != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_BACKSPACE) binding.setKey(-1);
            else binding.setKey(keyCode);
            binding = null;
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
