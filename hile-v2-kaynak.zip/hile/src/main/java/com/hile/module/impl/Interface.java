package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.module.ModuleManager;
import com.hile.setting.BoolSetting;
import com.hile.setting.ModeSetting;
import com.hile.setting.NumberSetting;
import com.hile.util.SoundFx;

public class Interface extends Module {
    private final ModeSetting accent = add(new ModeSetting("Accent", "Purple", "Cyan", "Pink", "Green", "Red", "Rainbow"));
    private final BoolSetting sounds = add(new BoolSetting("Menu Sounds", true));
    private final ModeSetting style = add(new ModeSetting("Sound Style", "Click", "Pling", "Bell", "Chime"));
    private final NumberSetting volume = add(new NumberSetting("Volume", 0.6, 0.1, 1.5, 0.1));

    public Interface() {
        super("Interface", "Menu temasi ve menu sesleri.", Category.CLIENT);
    }

    @Override public boolean showInList() { return false; }

    public String accentMode() { return accent.get(); }

    private String soundId() {
        switch (style.get()) {
            case "Pling": return "block.note_block.pling";
            case "Bell":  return "block.note_block.bell";
            case "Chime": return "block.amethyst_block.chime";
            default:      return "ui.button.click";
        }
    }

    private void play(float pitch) {
        if (!sounds.get()) return;
        SoundFx.play(soundId(), pitch, volume.getFloat());
    }

    private static Interface ui() { return ModuleManager.get(Interface.class); }

    public static void playToggle(boolean on) {
        Interface i = ui();
        if (i != null) i.play(on ? 1.5f : 0.9f);
    }

    public static void playOpen()  { Interface i = ui(); if (i != null) i.play(1.25f); }
    public static void playClose() { Interface i = ui(); if (i != null) i.play(0.8f); }
    public static void playTick()  { Interface i = ui(); if (i != null) i.play(1.1f); }
}
