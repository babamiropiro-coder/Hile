package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;

public class Sprint extends Module {
    public Sprint() {
        super("Sprint", "Ileri giderken otomatik kosar.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) return;
        if (p.forwardSpeed > 0 && !p.isSneaking() && !p.horizontalCollision && !p.isUsingItem()) {
            p.setSprinting(true);
        }
    }
}
