package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.module.ModuleManager;
import com.hile.setting.BoolSetting;
import com.hile.setting.ModeSetting;
import com.hile.setting.NumberSetting;
import com.hile.util.SoundFx;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

public class HitSounds extends Module {
    private static final Map<String, String> SOUNDS = new LinkedHashMap<>();
    static {
        SOUNDS.put("Orb", "entity.experience_orb.pickup");
        SOUNDS.put("Bell", "block.note_block.bell");
        SOUNDS.put("Pling", "block.note_block.pling");
        SOUNDS.put("Bonk", "block.note_block.basedrum");
        SOUNDS.put("Anvil", "block.anvil.land");
        SOUNDS.put("Crit", "entity.player.attack.crit");
        SOUNDS.put("Chime", "block.amethyst_block.chime");
        SOUNDS.put("Click", "ui.button.click");
        SOUNDS.put("Arrow", "entity.arrow.hit_player");
        SOUNDS.put("Bit", "block.note_block.bit");
        SOUNDS.put("Xylophone", "block.note_block.xylophone");
        SOUNDS.put("Level Up", "entity.player.levelup");
    }

    private static String[] withOff() {
        String[] out = new String[SOUNDS.size() + 1];
        out[0] = "Off";
        int i = 1;
        for (String k : SOUNDS.keySet()) out[i++] = k;
        return out;
    }

    private final ModeSetting playerSound = add(new ModeSetting("Player Hit", withOff()));
    private final ModeSetting mobSound = add(new ModeSetting("Mob Hit", withOff()));
    private final ModeSetting killSound = add(new ModeSetting("Kill Sound", withOff()));
    private final NumberSetting volume = add(new NumberSetting("Volume", 1.0, 0.1, 2.0, 0.1));
    private final NumberSetting pitch = add(new NumberSetting("Pitch", 1.0, 0.5, 2.0, 0.1));
    private final BoolSetting randomPitch = add(new BoolSetting("Random Pitch", true));

    private LivingEntity lastTarget;
    private int age;

    public HitSounds() {
        super("HitSounds", "Vurusta ve oldurmede ses cikarir.", Category.CLIENT);
        playerSound.cycle(1);
        mobSound.cycle(1);
    }

    private void play(String mode) {
        String id = SOUNDS.get(mode);
        if (id == null) return;
        float pt = pitch.getFloat();
        if (randomPitch.get()) pt *= 0.92f + ThreadLocalRandom.current().nextFloat() * 0.16f;
        SoundFx.play(id, pt, volume.getFloat());
    }

    public static void onAttack(Entity target) {
        HitSounds h = ModuleManager.get(HitSounds.class);
        if (h == null || !h.isEnabled() || !(target instanceof LivingEntity le)) return;
        h.play(target instanceof PlayerEntity ? h.playerSound.get() : h.mobSound.get());
        h.lastTarget = le;
        h.age = 0;
    }

    @Override
    public void onTick() {
        if (lastTarget == null) return;
        if (lastTarget.isDead() || lastTarget.getHealth() <= 0f) {
            play(killSound.get());
            lastTarget = null;
        } else if (++age > 60) {
            lastTarget = null;
        }
    }
}
