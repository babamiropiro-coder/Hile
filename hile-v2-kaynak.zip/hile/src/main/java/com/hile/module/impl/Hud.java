package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.module.ModuleManager;
import com.hile.setting.BoolSetting;
import com.hile.util.Render2D;
import com.hile.util.Theme;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Hud extends Module {
    private final BoolSetting watermark = add(new BoolSetting("Watermark", true));
    private final BoolSetting info = add(new BoolSetting("FPS / Ping", true));
    private final BoolSetting list = add(new BoolSetting("Module List", true));

    public Hud() {
        super("HUD", "Ekrandaki yazilar ve modul listesi.", Category.RENDER);
    }

    @Override public boolean showInList() { return false; }

    public void render(DrawContext ctx) {
        if (mc.player == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;

        if (watermark.get()) {
            String name = "Hile";
            String extra = "";
            if (info.get()) {
                int ping = 0;
                if (mc.getNetworkHandler() != null) {
                    PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                    if (e != null) ping = e.getLatency();
                }
                extra = "  " + mc.getCurrentFps() + " fps  " + ping + " ms";
            }
            int w = tr.getWidth(name) + tr.getWidth(extra) + 10;
            Render2D.rect(ctx, 4, 4, w, 14, 3, 0xB0101018);
            ctx.fill(4, 6, 6, 16, Theme.accent(0));
            int x = 9;
            for (int i = 0; i < name.length(); i++) {
                String ch = name.substring(i, i + 1);
                ctx.drawText(tr, ch, x, 7, Theme.accent(i * 14), true);
                x += tr.getWidth(ch);
            }
            if (!extra.isEmpty()) ctx.drawText(tr, extra, x, 7, 0xFFB8B8C8, true);
        }

        if (list.get()) {
            List<Module> shown = new ArrayList<>();
            for (Module m : ModuleManager.getModules()) if (m.isEnabled() && m.showInList()) shown.add(m);
            shown.sort(Comparator.comparingInt((Module m) -> tr.getWidth(m.getName())).reversed());

            int right = mc.getWindow().getScaledWidth() - 4;
            int y = 4;
            int idx = 0;
            for (Module m : shown) {
                int w = tr.getWidth(m.getName()) + 9;
                Render2D.rect(ctx, right - w, y, w, 11, 2, 0x90101018);
                ctx.fill(right - 2, y + 1, right, y + 10, Theme.accent(idx * 18));
                ctx.drawText(tr, m.getName(), right - w + 3, y + 2, Theme.accent(idx * 18), true);
                y += 12;
                idx++;
            }
        }
    }
}
