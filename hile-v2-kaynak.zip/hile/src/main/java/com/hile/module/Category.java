package com.hile.module;

public enum Category {
    COMBAT("Combat"),
    MOVEMENT("Movement"),
    RENDER("Render"),
    COSMETICS("Cosmetics"),
    CLIENT("Client");

    private final String label;

    Category(String label) { this.label = label; }

    public String label() { return label; }
}
