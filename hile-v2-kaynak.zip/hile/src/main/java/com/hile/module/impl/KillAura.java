package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.setting.BoolSetting;
import com.hile.setting.ModeSetting;
import com.hile.setting.NumberSetting;
import com.hile.util.TargetUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;

public class KillAura extends Module {
    private final NumberSetting range = add(new NumberSetting("Range", 3.0, 1.0, 6.0, 0.1));
    private final NumberSetting cps = add(new NumberSetting("CPS", 10, 1, 20, 1));
    private final BoolSetting cooldown = add(new BoolSetting("Cooldown (1.9+)", true));
    private final BoolSetting rotate = add(new BoolSetting("Rotate", true));
    private final ModeSetting sort = add(new ModeSetting("Sort", "Distance", "Health", "Angle"));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting hostile = add(new BoolSetting("Hostile Mobs", true));
    private final BoolSetting passive = add(new BoolSetting("Passive Mobs", false));
    private final BoolSetting invisible = add(new BoolSetting("Invisible", false));
    private final BoolSetting walls = add(new BoolSetting("Through Walls", false));

    private int ticks;

    public KillAura() {
        super("KillAura", "Yakindaki hedefe otomatik vurur.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        ticks++;

        LivingEntity target = TargetUtil.find(range.get(), players.get(), hostile.get(), passive.get(),
                invisible.get(), walls.get(), sort.get(), 360.0);
        if (target == null) return;

        if (cooldown.get()) {
            if (p.getAttackCooldownProgress(0.5f) < 1.0f) return;
        } else if (ticks < Math.max(1, Math.round(20f / cps.getFloat()))) {
            return;
        }

        if (rotate.get()) {
            float[] r = TargetUtil.rotations(target);
            p.setYaw(r[0]);
            p.setPitch(r[1]);
            p.prevYaw = r[0];
            p.prevPitch = r[1];
        }

        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);
        ticks = 0;
    }
}
