package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.module.ModuleManager;
import com.hile.setting.ModeSetting;
import net.minecraft.util.Identifier;

import java.util.Locale;

public class Cape extends Module {
    private final ModeSetting style = add(new ModeSetting("Style", "Hile", "Inferno", "Frost", "Shadow"));

    public Cape() {
        super("Cape", "Kendine ozel pelerin.", Category.COSMETICS);
    }

    /** Current cape texture, or null when disabled. */
    public static Identifier texture() {
        Cape c = ModuleManager.get(Cape.class);
        if (c == null || !c.isEnabled()) return null;
        return Identifier.of("hile", "textures/cape/" + c.style.get().toLowerCase(Locale.ROOT) + ".png");
    }
}
