package com.hile.module;

import com.hile.module.impl.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();

    private ModuleManager() {}

    public static void init() {
        MODULES.add(new Interface());
        MODULES.add(new Hud());
        MODULES.add(new KillAura());
        MODULES.add(new AimAssist());
        MODULES.add(new Sprint());
        MODULES.add(new Fullbright());
        MODULES.add(new HitSounds());
        MODULES.add(new Cape());
        MODULES.add(new Hat());

        get(Hud.class).setEnabled(true, false);
        get(Interface.class).setEnabled(true, false);
    }

    public static List<Module> getModules() { return Collections.unmodifiableList(MODULES); }

    public static List<Module> byCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) if (m.getCategory() == c) out.add(m);
        return out;
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T get(Class<T> type) {
        for (Module m : MODULES) if (type.isInstance(m)) return (T) m;
        return null;
    }

    public static void tick() {
        for (Module m : MODULES) if (m.isEnabled()) m.onTick();
    }

    public static void frame() {
        for (Module m : MODULES) if (m.isEnabled()) m.onFrame();
    }
}
