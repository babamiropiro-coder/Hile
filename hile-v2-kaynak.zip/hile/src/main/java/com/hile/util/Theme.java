package com.hile.util;

import com.hile.module.ModuleManager;
import com.hile.module.impl.Interface;
import net.minecraft.util.math.MathHelper;

public final class Theme {
    private Theme() {}

    /** Opaque ARGB accent color. offset shifts the rainbow / gradient phase. */
    public static int accent(float offset) {
        Interface ui = ModuleManager.get(Interface.class);
        String mode = ui == null ? "Purple" : ui.accentMode();
        switch (mode) {
            case "Cyan":  return 0xFF22D3EE;
            case "Pink":  return 0xFFF472B6;
            case "Green": return 0xFF4ADE80;
            case "Red":   return 0xFFF87171;
            case "Rainbow": {
                float hue = (((System.currentTimeMillis() / 25.0f) + offset) % 360f) / 360f;
                return MathHelper.hsvToRgb(hue, 0.55f, 1.0f) | 0xFF000000;
            }
            default: return 0xFFA855F7;
        }
    }

    public static int alpha(int rgb, int a) {
        return ((a & 0xFF) << 24) | (rgb & 0xFFFFFF);
    }
}
