package com.hile.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.List;

public class ModeSetting extends Setting {
    private final List<String> modes;
    private int index;

    public ModeSetting(String name, String... modes) {
        super(name);
        this.modes = List.of(modes);
    }

    public String get() { return modes.get(index); }
    public int getIndex() { return index; }
    public boolean is(String mode) { return get().equalsIgnoreCase(mode); }
    public List<String> getModes() { return modes; }

    public void cycle(int dir) {
        index = ((index + dir) % modes.size() + modes.size()) % modes.size();
    }

    @Override public JsonElement toJson() { return new JsonPrimitive(get()); }

    @Override public void fromJson(JsonElement e) {
        if (e == null || !e.isJsonPrimitive()) return;
        int i = modes.indexOf(e.getAsString());
        if (i >= 0) index = i;
    }
}
