# Hile (Fabric 1.21.1)

Menu: Sag Shift  |  veya sohbete /hile yaz
Moduller: KillAura, AimAssist, Sprint, Fullbright, HUD, HitSounds, Cape, Hat, Interface

## Jar'i derleme (GitHub, telefondan olur)
1. Bu klasoru GitHub'da yeni repo olarak yukle.
2. Actions > build > Run workflow.
3. Bitince "hile-jar" artifact'ini indir, icindeki hile-0.1.0.jar dosyasini mods klasorune at.
4. Gerekenler: Minecraft 1.21.1, Fabric Loader, Fabric API.

Ayarlar mods yerine config/hile.json dosyasina kaydedilir.
